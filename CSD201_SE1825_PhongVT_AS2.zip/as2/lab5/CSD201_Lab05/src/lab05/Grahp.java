
package lab05;

/**
 *
 * @author Cao The Quan - SE182750
 */
public class Grahp {
    int [][]a; // adjacency
    int n; 
    String[] v; // character for vertex
    public Grahp(){
        a = null; n = 0; v = null;
    }
    public Grahp(int[][] adjacencyMatrix, String[] vertices) {
        this.a = adjacencyMatrix;
        this.n = adjacencyMatrix.length;
        this.v = vertices;
    }
}
