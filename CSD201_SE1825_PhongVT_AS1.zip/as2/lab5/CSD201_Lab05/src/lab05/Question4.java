    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05;

import java.util.Arrays;

/**
 *
 * @author caoth
 */
public class Question4 {
    void assignColorsSequential(Grahp g) {
        int[] colors = new int[g.n];
        Arrays.fill(colors, -1); 

        colors[0] = 0;

        boolean[] available = new boolean[g.n];
        Arrays.fill(available, true);

        for (int u = 1; u < g.n; u++) {
            for (int v = 0; v < g.n; v++) {
                if (g.a[u][v] == 1 && colors[v] != -1) {
                    available[colors[v]] = false;
                }
            }

            int cr;
            for (cr = 0; cr < g.n; cr++) {
                if (available[cr]) {
                    break;
                }
            }

            colors[u] = cr; 

            Arrays.fill(available, true);
        }
        System.out.println("Assigned Colors:");
        for (int i = 0; i < g.n; i++) {
            System.out.println("Vertex " + g.v[i] + " --> Color " + colors[i]);
        }
    }

    public static void main(String[] args) {
        int[][] adjacencyMatrix = {
                {0, 1, 1, 0},
                {1, 0, 1, 1},
                {1, 1, 0, 1},
                {0, 1, 1, 0}
        };
        String[] vertices = {"A", "B", "C", "D"};
        Question4 q4 = new Question4();
        Grahp graph = new Grahp(adjacencyMatrix, vertices);
        q4.assignColorsSequential(graph);
    }
}
