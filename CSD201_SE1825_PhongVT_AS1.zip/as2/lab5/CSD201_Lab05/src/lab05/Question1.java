
package lab05;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.StringTokenizer;

/**
 *
 * @author caothequan
 */
class MyQueue{
    LinkedList<Integer> t;
    MyQueue() {t = new LinkedList<Integer>();}
    boolean isEmpty() {return(t.isEmpty());}
    void enqueue(int x) {t.add(x);}
    int dequeue() {return(t.removeFirst());}
}
public class Question1 {
    File f;
    public Question1(){
        String root = Paths.get("").toAbsolutePath().toString();
        f = new File(root+"\\File1.txt");
    }
    Grahp g = new Grahp();
    void loadData(String fName) throws IOException{
        int i, j;
        String s = "", s1 = "";
        StringTokenizer t;
        RandomAccessFile f = new RandomAccessFile(fName, "r");
        s = f.readLine();
        g.n = Integer.parseInt(s.trim());
        g.a = new int[g.n][g.n];
        for(i=0;i<g.n;i++) {
            s = f.readLine();
            t = new StringTokenizer(s);
            for(j=0;j<g.n;j++) {
                s1 = t.nextToken();
                g.a[i][j]=Integer.parseInt(s1.trim());
            }
        }
        f.close();
    }

    void setLabel(String [] c){
        g.v = new String[c.length];
        for(int i = 0;i<c.length;i++){
            g.v[i] = c[i];
        }
    }
    void visit(int i){
        System.out.print(g.v[i]+" ");
    }
    void depth(boolean[] visited, int i){
        visit(i); visited[i] = true;
        for(int j = 0;j<g.n;j++){
            if(!visited[j] && g.a[i][j]>0) depth(visited, j);
        }
    }
    void depth(int k){
        boolean[] visited = new boolean[g.n];
        int count = 1;
        for(int i = 0;i<g.n;i++) visited[i] = false;
        System.out.println("Depth-first traverse from the vertex " 
                + g.v[k] + ":");
        System.out.println("Depth-first traverse for connected part " 
                + count +":");
        depth(visited, k);
        int i;
        // because this is undirected graph => need only check 1 dimension
        for(i =0;i<g.n;i++){
            for(i =0;i<g.n;i++){
                if(!visited[i]){
                    count++;
                    System.out.println("\nDepth-first traverse for connected part " 
                            + count+":");
                    depth(visited, i);
                }
            }
        }
    }
    void breadth(int k){
        MyQueue q = new MyQueue();
        boolean [] enqueued = new boolean[g.n];
        int i,j;
        for(i=0;i<g.n;i++) enqueued[i]=false;
        q.enqueue(k); enqueued[k] = true;
        int r;
        System.out.println("\nBreadth-first traverse from the vertex " 
                + g.v[k] + ":");
        while(!q.isEmpty()) {
            r=q.dequeue(); visit(r);
            for(j=0;j<g.n;j++)
                if(!enqueued[j] && g.a[r][j]>0) {
                    q.enqueue(j); enqueued[j]=true;
                }
        }
        System.out.println();
    }
    public static void main(String args[]) throws IOException{
        Question1 q1 = new Question1();
        String filename = "File1.txt";
        q1.loadData(filename);
        String[] c = {"A", "B", "C", "D", "E", "F", "G", "H", "I"};
        q1.setLabel(c);
        q1.depth(0);
        q1.breadth(0);
        System.out.println("");
    }
}
