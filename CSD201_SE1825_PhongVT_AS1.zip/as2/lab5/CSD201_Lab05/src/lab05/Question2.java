package lab05;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.LinkedList;
import java.util.StringTokenizer;

class MyStack {
    LinkedList<Integer> a;

    MyStack() {
        a = new LinkedList<>();
    }

    boolean isEmpty() {
        return (a.isEmpty());
    }

    void push(int x) {
        a.add(x);
    }

    int pop() {
        return ((Integer) a.removeLast());
    }
}

class DijkstraGraph {
    int[][] a;
    int n;
    char[] b;
    static int INF = 99; // 99 is considered as infinite value

    DijkstraGraph() {
        String s1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        b = s1.toCharArray();
    }

    void setWeights(String filename) throws IOException {
    int i, j;
    String s = "", s1 = "";
    StringTokenizer t;
    RandomAccessFile f;
    f = new RandomAccessFile(filename, "r");
    s = f.readLine();
    n = Integer.parseInt(s.trim());
    a = new int[n][n];
    for (i = 0; i < n; i++) {
        s = f.readLine();
        t = new StringTokenizer(s);
        for (j = 0; j < n; j++) {
            if (t.hasMoreTokens()) {
                s1 = t.nextToken();
                try {
                    a[i][j] = Integer.parseInt(s1.trim());
                } catch (NumberFormatException e) {
                    // Handle non-integer input, set it to INF or handle as needed
                    a[i][j] = INF;  // Set to INF if not an integer
                }
            } else {
                // Handle missing values, set it to INF or handle as needed
                a[i][j] = INF;  // Set to INF if value is missing
            }
        }
    }
    f.close();
}


    void displayWeights() {
        int i, j;
        System.out.println("\n - The weighted matrix of the graph:");
        System.out.print(" ---------------------------------");
        for (i = 0; i < n; i++) {
            System.out.println();
            for (j = 0; j < n; j++)
                if (a[i][j] == INF)
                    System.out.printf(" INF");
                else
                    System.out.printf(" %3d", a[i][j]);
        }
        System.out.println();
    }

    void displayStep(int step, boolean[] selected, int[] dist, int[] path, int p, int[] sele, int nSele,
            boolean[] stopDisplay) {
        int i;
        String S = "";
        for (i = 0; i < nSele; i++)
            S = S + b[sele[i]];
        System.out.printf("\n\n %2d:  %10s", step, S);
        for (i = 0; i < n; i++) {
            if (i == p)
                continue;
            if (dist[i] == INF) {
                System.out.printf("  (%3s,%c)", "INF", b[path[i]]);
            } else {
                if (stopDisplay[i])
                    System.out.printf("         ");
                else
                    System.out.printf("  (%3d,%c)", dist[i], b[path[i]]);
            }
            if (selected[i])
                stopDisplay[i] = true;
        }
    }

    void dijkstra(boolean[] selected, int[] dist, int[] path, int p, int q, boolean[] stopDisplay) {
        int i, j, t, k, curr, step;
        for (i = 0; i < n; i++) {
            selected[i] = false;
            stopDisplay[i] = false;
            dist[i] = a[p][i];
            path[i] = p;
        }
        int[] sele = new int[50];
        int nSele = 0;
        selected[p] = true;
        sele[nSele++] = p;
        curr = p;
        System.out.println("\n - Dijkstra algorithm for shortest path from " + b[p] + " to  " + b[q] + ":");
        System.out.println(" ------------------------------------------------"
                + "-------------------------");
        System.out.print("      The S set: ");
        for (i = 0; i < n; i++) {
            if (i == p)
                continue;
            System.out.printf("        %c", b[i]);
        }
        step = 0;
        displayStep(step, selected, dist, path, p, sele, nSele, stopDisplay);
        while (curr != q) {
            t = INF;
            k = -1;
            for (i = 0; i < n; i++) {
                if (i == p || selected[i])
                    continue;
                if (dist[i] < t) {
                    t = dist[i];
                    k = i;
                }
            }
            if (t == INF) {
                System.out.println("\nKhong co duong di");
                return;
            }
            selected[k] = true;
            curr = k;
            sele[nSele++] = k;
            for (i = 0; i < n; i++) {
                if (i == p || selected[i])
                    continue;
                if (dist[i] > dist[k] + a[k][i]) {
                    dist[i] = dist[k] + a[k][i];
                    path[i] = k;
                }
            }
            step++;
            displayStep(step, selected, dist, path, p, sele, nSele, stopDisplay);
        }
    }

    void pathDijkstra(int[] dist, int[] path, int p, int q) {
        MyStack s = new MyStack();
        int i;
        System.out.println("\n\n - The length of shortest path from " + b[p] + " to  " + b[q] + " is: " + dist[q]);
        System.out.print("\n - Path: ");
        i = q;
        s.push(i);
        do {
            i = path[i];
            s.push(i);
        } while (i != p);
        System.out.print(" ");
        while (!s.isEmpty()) {
            i = s.pop();
            System.out.print(b[i]);
            if (i != q)
                System.out.print(" -> ");
        }
    }

    void dijkstra(int p, int q) {
        boolean[] selected = new boolean[n];
        boolean[] stopDisplay = new boolean[n];
        int[] dist = new int[n];
        int[] path = new int[n];
        dijkstra(selected, dist, path, p, q, stopDisplay);
        pathDijkstra(dist, path, p, q);
    }
}

public class Question2 {
    public static void main(String[] args) throws IOException {
        String filename;
        filename = "File2.txt";
        DijkstraGraph g = new DijkstraGraph();
        g.setWeights(filename);
        g.displayWeights();
        g.dijkstra(0, 5); 
        System.out.println("\n ");
    }
}
