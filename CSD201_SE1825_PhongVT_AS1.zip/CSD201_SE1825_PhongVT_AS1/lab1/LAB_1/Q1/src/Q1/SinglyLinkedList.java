/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q1;

/**
 *
 * @author My Compter
 */
class SinglyLinkedList {
    private Node head;
    private Node tail;

    public SinglyLinkedList() {
        head = null;
        tail = null;
    }

// 1: Add to Head
    public void addToHead(int x) {
        Node newNode = new Node(x);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

//2: Add to Tail
    public void addToTail(int x) {
        Node newNode = new Node(x);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }

//3: Add After
    public void addAfter(Node p, int x) {
        if (p == null) {
            System.out.println("Invalid node reference.");
            return;
        }
        Node newNode = new Node(x);
        newNode.next = p.next;
        p.next = newNode;
        if (p == tail) {
            tail = newNode;
        }
    }

//4: Traverse   
    public void traverse() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

//5: Count    
    public int count() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

//6: Delete From Head    
    public int deleteFromHead() {
        if (head == null) {
            System.out.println("List is empty.");
            return -1;
        }
        int deletedData = head.data;
        head = head.next;
        if (head == null) {
            tail = null;
        }
        return deletedData;
    }

//7: Delete From Tail    
    public int deleteFromTail() {
        if (tail == null) {
            System.out.println("List is empty.");
            return -1;
        }
        int deletedData = tail.data;
        if (head == tail) {
            head = null;
            tail = null;
        } else {
            Node current = head;
            while (current.next != tail) {
                current = current.next;
            }
            current.next = null;
            tail = current;
        }
        return deletedData;
    }

//8: Delete After    
    public int deleteAfter(Node p) {
        if (p == null || p.next == null) {
            System.out.println("Invalid node reference.");
            return -1;
        }
        Node deletedNode = p.next;
        p.next = deletedNode.next;
        if (deletedNode == tail) {
            tail = p;
        }
        return deletedNode.data;
    }

//9: Delete Node    
    public void deleteNode(int x) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        if (head.data == x) {
            deleteFromHead();
            return;
        }
        Node current = head;
        while (current.next != null && current.next.data != x) {
            current = current.next;
        }
        if (current.next == null) {
            System.out.println("Node with value " + x + " not found.");
            return;
        }
        current.next = current.next.next;
        if (current.next == null) {
            tail = current;
        }
    }

//10: Search
    public Node search(int x) {
        Node current = head;
        while (current != null) {
            if (current.data == x) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

//11: Delete    
    public void delete(Node p) {
        if (p == null) {
            System.out.println("Invalid node reference.");
            return;
        }
        if (head == p) {
            deleteFromHead();
            return;
        }
        Node current = head;
        while (current.next != null && current.next != p) {
            current = current.next;
        }
        if (current.next == null) {
            System.out.println("Node not found.");
            return;
        }
        current.next = current.next.next;
        if (current.next == null) {
            tail = current;
        }
    }

//12: Delete Node2    
    public void deleteNode2(int i) {
        if (i <= 0 || head == null) {
            System.out.println("Invalid index or list is empty.");
            return;
        }
        if (i == 1) {
            deleteFromHead();
            return;
        }
        Node current = head;
        int count = 1;
        while (count < i - 1 && current != null) {
            current = current.next;
            count++;
        }
        if (current == null || current.next == null) {
            System.out.println("Node not found.");
            return;
        }
        current.next = current.next.next;
        if (current.next == null) {
            tail = current;
        }
    }

//13: Add Before    
    public void addBefore(Node p, int x) {
        if (p == null) {
            System.out.println("Invalid node reference.");
            return;
        }
        if (head == p) {
            addToHead(x);
            return;
        }
        Node current = head;
        while (current.next != null && current.next != p) {
            current = current.next;
        }
        if (current.next == null) {
            System.out.println("Node not found.");
            return;
        }
        Node newNode = new Node(x);
        newNode.next = current.next;
        current.next = newNode;
    }

//14: Sort    
    public void sort() {
        if (head == null || head.next == null) {
            return;
        }
        Node current = head;
        while (current != null) {
            Node nextNode = current.next;
            while (nextNode != null) {
                if (current.data > nextNode.data) {
                    int temp = current.data;
                    current.data = nextNode.data;
                    nextNode.data = temp;
                }
                nextNode = nextNode.next;
            }
            current = current.next;
        }
    }

//15: Reverse a singly linked list using only one pass through the list    
    public void reverse() {
        if (head == null || head.next == null) {
            return;
        }
        Node prev = null;
        Node current = head;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        tail = head;
        head = prev;
    }

//16: To Array    
    public int[] toArray() {
        int[] arr = new int[count()];
        Node current = head;
        int index = 0;
        while (current != null) {
            arr[index] = current.data;
            current = current.next;
            index++;
        }
        return arr;
    }

//17: Merge two ordered singly linked lists of integers into one ordered list    
    public static SinglyLinkedList merge(SinglyLinkedList list1, SinglyLinkedList list2) {
        SinglyLinkedList mergedList = new SinglyLinkedList();
        Node node1 = list1.head;
        Node node2 = list2.head;
        while (node1 != null && node2 != null) {
            if (node1.data <= node2.data) {
                mergedList.addToTail(node1.data);
                node1 = node1.next;
            } else {
                mergedList.addToTail(node2.data);
                node2 = node2.next;
            }
        }
        while (node1 != null) {
            mergedList.addToTail(node1.data);
            node1 = node1.next;
        }
        while (node2 != null) {
            mergedList.addToTail(node2.data);
            node2 = node2.next;
        }
        return mergedList;
    }

//18: Attach a singly linked list to the end of another singly linked list    
    public void attach(SinglyLinkedList list) {
        if (list.head == null) {
            return;
        }
        if (head == null) {
            head = list.head;
            tail = list.tail;
        } else {
            tail.next = list.head;
            tail = list.tail;
        }
    }

//19: Max    
    public int max() {
        if (head == null) {
            System.out.println("List is empty.");
            return Integer.MIN_VALUE;
        }
        int maxValue = head.data;
        Node current = head.next;
        while (current != null) {
            if (current.data > maxValue) {
                maxValue = current.data;
            }
            current = current.next;
        }
        return maxValue;
    }

//20: Min    
    public int min() {
        if (head == null) {
            System.out.println("List is empty.");
            return Integer.MAX_VALUE;
        }
        int minValue = head.data;
        Node current = head.next;
        while (current != null) {
            if (current.data < minValue) {
                minValue = current.data;
            }
            current = current.next;
        }
        return minValue;
    }

//21: Sum    
    public int sum() {
        int sum = 0;
        Node current = head;
        while (current != null) {
            sum += current.data;
            current = current.next;
        }
        return sum;
    }

//22: Avg    
    public int avg() {
        if (head == null) {
            System.out.println("List is empty.");
            return 0;
        }
        int sum = sum();
        int count = count();
        return sum / count;
    }

//23: Sorted    
    public boolean sorted() {
        Node current = head;
        while (current != null && current.next != null) {
            if (current.data > current.next.data) {
                return false;
            }
            current = current.next;
        }
        return true;
    }
    
//24: Insert    
   void insert(int x) {
        if (head == null || x <= head.data) {
            addToHead(x);
            return;
        }
        Node current = head;
        while (current.next != null && current.next.data < x) {
            current = current.next;
        }
        addAfter(current, x);
    }
   
//25: Check whether two singly linked lists have the same contents   
   boolean sameContents(SinglyLinkedList list) {
        Node current1 = head;
        Node current2 = list.head;
        while (current1 != null && current2 != null) {
            if (current1.data != current2.data) {
                return false;
            }
            current1 = current1.next;
            current2 = current2.next;
        }
        return current1 == null && current2 == null;
    }
}
