/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q1;

/**
 *
 * @author My Compter
 */
public class Main {

  public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.addToTail(10);
        list.addToTail(20);
        list.addToTail(30);
        list.traverse(); // Output: 10 20 30

        list.addToHead(5);
        list.traverse(); // Output: 5 10 20 30

        Node node = list.search(20);
        list.addAfter(node, 25);
        list.traverse(); // Output: 5 10 20 25 30

        System.out.println("Number of nodes: " + list.count()); // Output: 5

        System.out.println("Deleting from head: " + list.deleteFromHead()); // Output: 5
        list.traverse(); // Output: 10 20 25 30

        System.out.println("Deleting node with value 25");
        list.deleteNode(25);
        list.traverse(); // Output: 10 20 30

        // Add more test cases or operations as per your requirements
    }
}
    
