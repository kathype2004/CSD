/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q3;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         DoublyLinkedList list = new DoublyLinkedList();
        
        // Thực hiện các thao tác trên danh sách liên kết kép
        list.addToHead(5);
        list.addToTail(10);
        list.addToTail(15);
        list.traverse();
        
        System.out.println("Số lượng nút trong danh sách: " + list.count());
        
        list.deleteFromHead();
        list.traverse();
        
        list.addAfter(list.head, 20);
        list.traverse();
        
        // Thực hiện các thao tác khác tùy ý
        
        // Kiểm tra việc đảo ngược danh sách liên kết đơn
        Node head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(3);
        System.out.println("Danh sách ban đầu:");
        list.traverse();
        list.reverseSinglyList(head);
        System.out.println("Danh sách sau khi đảo ngược:");
        list.traverse();
        
        // Kiểm tra việc so sánh nội dung của hai danh sách liên kết đơn
        Node head1 = new Node(1);
        head1.next = new Node(2);
        head1.next.next = new Node(3);
        Node head2 = new Node(1);
        head2.next = new Node(2);
        head2.next.next = new Node(3);
        System.out.println("Hai danh sách có cùng nội dung không? " + list.sameContentsSinglyList(head1, head2));
    }
    
}
