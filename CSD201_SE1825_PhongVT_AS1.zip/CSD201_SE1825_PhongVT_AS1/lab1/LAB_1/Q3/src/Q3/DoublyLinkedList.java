/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q3;

/**
 *
 * @author My Compter
 */
class DoublyLinkedList {
     Node head;
    private Node tail;
    private int size;

    // Add a node with value x at the head of the list
    public void addToHead(int x) {
        Node newNode = new Node(x);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        size++;
    }

    // Add a node with value x at the tail of the list
    public void addToTail(int x) {
        Node newNode = new Node(x);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    // Add a node with value x after the node p
    public void addAfter(Node p, int x) {
        if (p == null) {
            System.out.println("Node p is null.");
            return;
        }
        if (p == tail) {
            addToTail(x);
        } else {
            Node newNode = new Node(x);
            newNode.next = p.next;
            newNode.prev = p;
            p.next.prev = newNode;
            p.next = newNode;
            size++;
        }
    }

    // Traverse from head to tail and display info of all nodes in the list
    public void traverse() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Count and return the number of nodes in the list
    public int count() {
        return size;
    }

    // Delete the head and return its info
    public int deleteFromHead() {
        if (head == null) {
            System.out.println("List is empty.");
            return -1;
        }
        int data = head.data;
        head = head.next;
        if (head != null) {
            head.prev = null;
        } else {
            tail = null;
        }
        size--;
        return data;
    }
     // Delete the tail and return its info
    public int deleteFromTail() {
        if (tail == null) {
            System.out.println("List is empty.");
            return -1;
        }
        int data = tail.data;
        tail = tail.prev;
        if (tail != null) {
            tail.next = null;
        } else {
            head = null;
        }
        size--;
        return data;
    }

    // Delete the node after the node p and return its info
    public int deleteAfter(Node p) {
        if (p == null || p.next == null) {
            System.out.println("Node p is null or p is the last node.");
            return -1;
        }
        int data = p.next.data;
        p.next = p.next.next;
        if (p.next != null) {
            p.next.prev = p;
        } else {
            tail = p;
        }
        size--;
        return data;
    }

    // Delete the first node whose info is equal to x
    public void deleteNode(int x) {
        Node current = head;
        while (current != null) {
            if (current.data == x) {
                if (current == head) {
                    deleteFromHead();
                } else if (current == tail) {
                    deleteFromTail();
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                    size--;
                }
                return;
            }
            current = current.next;
        }
    }

    // Search and return the reference to the first node having info x
    public Node search(int x) {
        Node current = head;
        while (current != null) {
            if (current.data == x) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    // Delete node p if it exists in the list
    public void delete(Node p) {
        if (p == null) {
            return;
        }
        if (p == head) {
            deleteFromHead();
        } else if (p == tail) {
            deleteFromTail();
        } else {
            p.prev.next = p.next;
            p.next.prev = p.prev;
            size--;
        }
    }

    // Delete the i-th node on the list
    public void deleteNode2(int i) {
        if (i < 0 || i >= size) {
            System.out.println("Invalid index.");
            return;
        }
        Node current = head;
        for (int j = 0; j < i; j++) {
            current = current.next;
        }
        delete(current);
    }

    // Add a node with value x before the node p
    public void addBefore(Node p, int x) {
        if (p == null) {
            System.out.println("Node p is null.");
            return;
        }
        if (p == head) {
            addToHead(x);
        } else {
            Node newNode = new Node(x);
            newNode.prev = p.prev;
            newNode.next = p;
            p.prev.next = newNode;
            p.prev = newNode;
            size++;
        }
    }

    // Sort the list by ascending order of info
    public void sort() {
        // Implement sorting logic here
    }

    // Reverse a doubly linked list
    public void reverse() {
        Node current = head;
        Node temp = null;
        while (current != null) {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        }
        if (temp != null) {
            head = temp.prev;
        }
    }

    // Create and return array containing info of all nodes in the list
    public int[] toArray() {
        int[] arr = new int[size];
        Node current = head;
        int index = 0;
        while (current != null) {
            arr[index++] = current.data;
            current = current.next;
        }
        return arr;
    }
// Merge two ordered doubly linked lists of integers into one ordered list
    public static DoublyLinkedList merge(DoublyLinkedList list1, DoublyLinkedList list2) {
        DoublyLinkedList mergedList = new DoublyLinkedList();
        Node current1 = list1.head;
        Node current2 = list2.head;
        while (current1 != null && current2 != null) {
            if (current1.data < current2.data) {
                mergedList.addToTail(current1.data);
                current1 = current1.next;
            } else {
                mergedList.addToTail(current2.data);
                current2 = current2.next;
            }
        }
        while (current1 != null) {
            mergedList.addToTail(current1.data);
            current1 = current1.next;
        }
        while (current2 != null) {
            mergedList.addToTail(current2.data);
            current2 = current2.next;
        }
        return mergedList;
    }

    // Attach a doubly linked list to the end of another doubly linked list
    public void attach(DoublyLinkedList list) {
        if (list.head != null) {
            if (head == null) {
                head = list.head;
                tail = list.tail;
            } else {
                tail.next = list.head;
                list.head.prev = tail;
                tail = list.tail;
            }
            size += list.size;
        }
    }

    // Find and return the maximum value in the list
    public int max() {
        if (head == null) {
            System.out.println("List is empty.");
            return Integer.MIN_VALUE;
        }
        int max = head.data;
        Node current = head.next;
        while (current != null) {
            if (current.data > max) {
                max = current.data;
            }
            current = current.next;
        }
        return max;
    }

    // Find and return the minimum value in the list
    public int min() {
        if (head == null) {
            System.out.println("List is empty.");
            return Integer.MAX_VALUE;
        }
        int min = head.data;
        Node current = head.next;
        while (current != null) {
            if (current.data < min) {
                min = current.data;
            }
            current = current.next;
        }
        return min;
    }

    // Return the sum of all values in the list
    public int sum() {
        int sum = 0;
        Node current = head;
        while (current != null) {
            sum += current.data;
            current = current.next;
        }
        return sum;
    }

    // Return the average of all values in the list
    public double avg() {
        if (size == 0) {
            return 0;
        }
        return (double) sum() / size;
    }

    // Check and return true if the list is sorted, return false if the list is not sorted
    public boolean sorted() {
        Node current = head;
        while (current != null && current.next != null) {
            if (current.data > current.next.data) {
                return false;
            }
            current = current.next;
        }
        return true;
    }

    // Insert node with value x into sorted list so that the new list is sorted
    public void insert(int x) {
        if (head == null || x <= head.data) {
            addToHead(x);
            return;
        }
        Node current = head;
        while (current.next != null && current.next.data < x) {
            current = current.next;
        }
        addAfter(current, x);
    }

    // Check whether two doubly linked lists have the same contents
    public boolean sameContents(DoublyLinkedList list) {
        if (size != list.size) {
            return false;
        }
        Node current1 = head;
        Node current2 = list.head;
        while (current1 != null) {
            if (current1.data != current2.data) {
                return false;
            }
            current1 = current1.next;
            current2 = current2.next;
        }
        return true;
    }
// Reverse a singly linked list using only one pass through the list
public void reverseSinglyList(Node head) {
    Node prev = null;
    Node current = head;
    Node next = null;
    while (current != null) {
        next = current.next;
        current.next = prev;
        prev = current;
        current = next;
    }
    head = prev;
}

// Return true if two singly linked lists have the same contents, otherwise false
public boolean sameContentsSinglyList(Node head1, Node head2) {
    while (head1 != null && head2 != null) {
        if (head1.data != head2.data) {
            return false;
        }
        head1 = head1.next;
        head2 = head2.next;
    }
    return head1 == null && head2 == null;
}

}
