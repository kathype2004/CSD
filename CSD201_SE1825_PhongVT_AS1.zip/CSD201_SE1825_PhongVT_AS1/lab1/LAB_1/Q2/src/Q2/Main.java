/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q2;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

    SinglyLinkedList list = new SinglyLinkedList();
        
        list.addToHead("C");
        list.addToHead("B");
        list.addToHead("A");
        list.traverse(); // Output: A B C

        list.addToTail("D");
        list.traverse(); // Output: A B C D

        Node nodeC = list.search("C");
        list.addAfter(nodeC, "E");
        list.traverse(); // Output: A B C E D

        System.out.println("Number of nodes: " + list.count()); // Output: 5

        System.out.println("Deleting from head: " + list.deleteFromHead()); // Output: A
        list.traverse(); // Output: B C E D

        System.out.println("Deleting from tail: " + list.deleteFromTail()); // Output: D
        list.traverse(); // Output: B C E

        Node nodeE = list.search("E");
        System.out.println("Deleting node after E: " + list.deleteAfter(nodeE)); // Output: D
        list.traverse(); // Output: B C E

        System.out.println("Deleting node with value C");
        list.deleteNode("C");
        list.traverse(); // Output: B E

        Node searchResult = list.search("E");
        if (searchResult != null) {
            System.out.println("Found node with value E");
        } else {
            System.out.println("Node with value E not found");
        }
    }
}

