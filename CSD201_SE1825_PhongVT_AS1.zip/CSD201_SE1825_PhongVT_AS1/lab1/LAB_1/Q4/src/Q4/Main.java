/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        list.addToHead(5);
        list.addToTail(10);
        list.addToTail(15);
        list.traverse();
        System.out.println("Number of nodes in the list: " + list.count());
        list.deleteFromHead();
        list.traverse();
        list.addAfter(list.head, 20);
        list.traverse();

        // Other operations can be tested here
        // For example:
        // list.deleteFromTail();
        // list.addBefore(list.head.next, 25);
        // Node searchResult = list.search(10);
        // list.deleteNode(15);
        // list.sort();
        // list.reverseSinglyList();
        // int[] arr = list.toArray();
        // CircularLinkedList list2 = new CircularLinkedList();
        // list2.addToHead(3);
        // list2.addToTail(12);
        // CircularLinkedList mergedList = CircularLinkedList.merge(list, list2);
        // list.attach(list2);
        // int max = list.max();
        // int min = list.min();
        // int sum = list.sum();
        // double avg = list.avg();
        // boolean isSorted = list.sorted();
        // list.insert(8);
        // boolean sameContents = list.sameContents(list2);
    }
    
}
