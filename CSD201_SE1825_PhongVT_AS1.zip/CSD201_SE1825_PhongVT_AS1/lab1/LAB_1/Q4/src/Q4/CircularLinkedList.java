/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

/**
 *
 * @author My Compter
 */
class CircularLinkedList {
     Node head;
    private Node tail;

    // Add a node with value x at the head of the list
    public void addToHead(int x) {
        Node newNode = new Node(x);
        if (head == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
        } else {
            newNode.next = head;
            head = newNode;
            tail.next = head;
        }
    }

    // Add a node with value x at the tail of the list
    public void addToTail(int x) {
        Node newNode = new Node(x);
        if (tail == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
        } else {
            tail.next = newNode;
            tail = newNode;
            tail.next = head;
        }
    }

    // Add a node with value x after the node p
    public void addAfter(Node p, int x) {
        if (p == null) {
            System.out.println("Node p is null.");
            return;
        }
        Node newNode = new Node(x);
        newNode.next = p.next;
        p.next = newNode;
    }

    // Traverse from head to tail and display info of all nodes in the list
    public void traverse() {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    // Count and return the number of nodes in the list
    public int count() {
        if (head == null) {
            return 0;
        }
        int count = 0;
        Node current = head;
        do {
            count++;
            current = current.next;
        } while (current != head);
        return count;
    }

    // Delete the head and return its info
    public int deleteFromHead() {
        if (head == null) {
            System.out.println("List is empty.");
            return -1;
        }
        int data = head.data;
        if (head == tail) {
            head = null;
            tail = null;
        } else {
            head = head.next;
            tail.next = head;
        }
        return data;
    }

    // Delete the tail and return its info
    public int deleteFromTail() {
        if (tail == null) {
            System.out.println("List is empty.");
            return -1;
        }
        int data = tail.data;
        if (head == tail) {
            head = null;
            tail = null;
        } else {
            Node current = head;
            while (current.next != tail) {
                current = current.next;
            }
            tail = current;
            tail.next = head;
        }
        return data;
    }
     // Delete the node after the node p and return its info
    public int deleteAfter(Node p) {
        if (p == null || p.next == null || p.next == head) {
            System.out.println("Node p is null or p is the last node.");
            return -1;
        }
        int data = p.next.data;
        if (p.next == tail) {
            p.next = head;
            tail = p;
        } else {
            p.next = p.next.next;
        }
        return data;
    }

    // Delete the first node whose info is equal to x
    public void deleteNode(int x) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        if (head.data == x) {
            deleteFromHead();
        } else {
            Node current = head;
            while (current.next != head) {
                if (current.next.data == x) {
                    if (current.next == tail) {
                        deleteFromTail();
                    } else {
                        current.next = current.next.next;
                    }
                    return;
                }
                current = current.next;
            }
        }
    }

    // Search and return the reference to the first node having info x
    public Node search(int x) {
        if (head == null) {
            return null;
        }
        Node current = head;
        do {
            if (current.data == x) {
                return current;
            }
            current = current.next;
        } while (current != head);
        return null;
    }

    // Delete node p if it exists in the list
    public void delete(Node p) {
        if (p == null || head == null) {
            return;
        }
        if (p == head) {
            deleteFromHead();
        } else {
            Node current = head;
            while (current.next != head) {
                if (current.next == p) {
                    if (p == tail) {
                        deleteFromTail();
                    } else {
                        current.next = p.next;
                    }
                    return;
                }
                current = current.next;
            }
        }
    }

    // Delete the i-th node on the list
    public void deleteNode2(int i) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        if (i <= 0) {
            deleteFromHead();
        } else {
            Node current = head;
            for (int index = 0; index < i - 1; index++) {
                current = current.next;
                if (current == head) {
                    System.out.println("Invalid index.");
                    return;
                }
            }
            delete(current);
        }
    }

    // Add a node with value x before the node p
    public void addBefore(Node p, int x) {
        if (p == null || head == null) {
            System.out.println("Node p is null or list is empty.");
            return;
        }
        if (p == head) {
            addToHead(x);
        } else {
            Node current = head;
            do {
                if (current.next == p) {
                    Node newNode = new Node(x);
                    newNode.next = p;
                    current.next = newNode;
                    return;
                }
                current = current.next;
            } while (current != head);
        }
    }

    // Sort the list by ascending order of info
    public void sort() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node current = head;
        do {
            Node index = current.next;
            while (index != head) {
                if (current.data > index.data) {
                    int temp = current.data;
                    current.data = index.data;
                    index.data = temp;
                }
                index = index.next;
            }
            current = current.next;
        } while (current.next != head);
    }

    // Reverse a singly linked list using only one pass through the list
    public void reverseSinglyList() {
        if (head == null || head.next == head) {
            return;
        }
        Node prev = null;
        Node current = head;
        Node nextNode;
        do {
            nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
        } while (current != head);
        head.next = prev;
        head = prev;
    }

    // Create and return an array containing info of all nodes in the list
    public int[] toArray() {
    if (head == null) {
        return new int[0];
    }
    int[] arr = new int[count()];
    Node current = head;
    int index = 0;
    do {
        arr[index++] = current.data;
        current = current.next;
    } while (current != head);
    return arr;
}

    // Merge two ordered circular linked lists of integers into one ordered list
    public static CircularLinkedList merge(CircularLinkedList list1, CircularLinkedList list2) {
        CircularLinkedList mergedList = new CircularLinkedList();
        Node current1 = list1.head;
        Node current2 = list2.head;
        do {
            if (current1.data < current2.data) {
                mergedList.addToTail(current1.data);
                current1 = current1.next;
            } else {
                mergedList.addToTail(current2.data);
                current2 = current2.next;
            }
        } while (current1 != list1.head && current2 != list2.head);
        while (current1 != list1.head) {
            mergedList.addToTail(current1.data);
            current1 = current1.next;
        }
        while (current2 != list2.head) {
            mergedList.addToTail(current2.data);
            current2 = current2.next;
        }
        return mergedList;
    }

    // Attach a circular linked list to the end of another circular linked list
    public void attach(CircularLinkedList list) {
        if (list.head != null) {
            if (head == null) {
                head = list.head;
                tail = list.tail;
            } else {
                tail.next = list.head;
                list.tail.next = head;
                tail = list.tail;
            }
        }
    }

    // Find and return the maximum value in the list
    public int max() {
        if (head == null) {
            System.out.println("List is empty.");
            return Integer.MIN_VALUE;
        }
        int max = head.data;
        Node current = head.next;
        do {
            if (current.data > max) {
                max = current.data;
            }
            current = current.next;
        } while (current != head);
        return max;
    }

    // Find and return the minimum value in the list
    public int min() {
        if (head == null) {
            System.out.println("List is empty.");
            return Integer.MAX_VALUE;
        }
        int min = head.data;
        Node current = head.next;
        do {
            if (current.data < min) {
                min = current.data;
            }
            current = current.next;
        } while (current != head);
        return min;
    }

    // Return the sum of all values in the list
    public int sum() {
        if (head == null) {
            return 0;
        }
        int sum = 0;
        Node current = head;
        do {
            sum += current.data;
            current = current.next;
        } while (current != head);
        return sum;
    }

    // Return the average of all values in the list
    public double avg() {
        int size = count();
        if (size == 0) {
            return 0;
        }
        return (double) sum() / size;
    }

    // Check and return true if the list is sorted, return false if the list is not sorted
    public boolean sorted() {
        if (head == null) {
            return true;
        }
        Node current = head;
        do {
            if (current.data > current.next.data) {
                return false;
            }
            current = current.next;
        } while (current.next != head);
        return true;
    }

    // Insert node with value x into sorted list so that the new list is sorted
    public void insert(int x) {
        Node newNode = new Node(x);
        if (head == null || x <= head.data) {
            addToHead(x);
            return;
        }
        Node current = head;
        do {
            if (x < current.next.data || current.next == head) {
                newNode.next = current.next;
                current.next = newNode;
                return;
            }
            current = current.next;
        } while (current != head);
    }

    // Check whether two circular linked lists have the same contents
    public boolean sameContents(CircularLinkedList list) {
        if (count() != list.count()) {
            return false;
        }
        Node current1 = head;
        Node current2 = list.head;
        do {
            if (current1.data != current2.data) {
                return false;
            }
            current1 = current1.next;
            current2 = current2.next;
        } while (current1 != head);
        return true;
    }

}
