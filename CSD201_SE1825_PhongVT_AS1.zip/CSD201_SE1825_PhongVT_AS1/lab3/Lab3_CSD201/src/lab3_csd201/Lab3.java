
package lab3_csd201;

/**
 *
 * @author PC
 */
class Node{
    int info;
    Node left, right;
    public Node(int x){
        this.info = x;
        left = right = null;
    }
}
public class Lab3 {
    // Q1
    int sum(int n){
        if(n==0) return 0;
        return (n+sum(n-1));
    }
    // Q2
    int findMin(int a[], int n) {
        // Base case: If the array has only one element, it is the minimum
        if (n == 1) {
            return a[0];
        }

        // Recursive case: Find the minimum element in the rest of the array
        int restMin = findMin(a, n - 1);

        // Compare the minimum of the rest with the last element in the array
        return Math.min(restMin, a[n - 1]);
    }
    // Q3
    int findSum(int[] a, int n){
        if(n==1) return a[0];
        return a[n-1]+findSum(a, n-1);
    }
    // Q4: return 1: is palidrome, 0: not
    int ispalindrome(char a[], int n){ // n: lenght of array character
        int start = a.length-n;
        int end = n-1;
        if(start >= end) return 1;
        if(a[start]==a[end]){
            return ispalindrome(a, n-1);
        }
        return 0;
    }
    // Q5: return index of target in array
    int findTarget(int[] a, int n, int target){
        int low, high, mid;
        high = n-1;
        low = a.length-n;
        mid = (high-low)/2;
        if(a[mid]>target){
            high = mid;
            int[] b = null;
            for(int i=0;i<high;i++){
                b[i]=a[i];
            }
            return findTarget(b, high+1, target);
        }
        if(a[mid]<target){
            low = mid;
            int[] b = null;
            for(int i=low;i<=high;i++){
                b[i]=a[i];
            }
            return findTarget(b, low, target)+low;
        }
        if(a[mid]==target) return mid;
        else return -1;
    }
    // Q6
    int GCD(int a, int b){
        if(a>b) return GCD(a-b, b);
        else if(a<b) return GCD(a, b-a);
        return a; // if(a==b)
    }
    // Q7
    int power(int x, int n){
        if(n==0) return 1;
        return x*power(x, n-1);
    }
    // Q8
    int fact(int n){
        if(n==1) return 1;
        return n*fact(n-1);
    }
    // Q9
    int fib(int n){
        if(n==0) return 0;
        if(n==1||n==2) return 1;
        return fib(n-1)+fib(n-2);
    }
    // Q10
    double addReciprocals(int n){
        if(n==1) return 1.0;
        return (double)1/n+(double)addReciprocals(n-1);
    }
    // Q11-Q12
    Node root;
    public Lab3() {
        root = null;
    }
    int height(Node root){ // Q11
        if(root == null) return 0;
        return 1+Math.max(height(root.left), height(root.right));
    }
    int size(Node root){ // Q12
        if(root == null) return 0;
        return 1+size(root.left)+size(root.right);
    }
    public static void main(String[] args) {
        Lab3 l = new Lab3();
        System.out.print("the sum of all numbers from 1 to "+10+" is: "+ l.sum(10)); // Q1
        int[] arr = {12,19,45,32,11,6,16,34,23,10};
        int n = 10;
        System.out.println("");
        System.out.println("the minimum element in an array: "+l.findMin(arr, n));// Q2
        System.out.println("the sum of all elements in an array: "+l.findSum(arr, n)); // Q3
        // Q4
        char[] c = {'a', 'b', 'c','d','c','b', 'a'};
        if(l.ispalindrome(c, 7)==1) System.out.println("an array is a palidrome");
        else System.out.println("an array is not a palidrome");
        // Q5
        System.out.println("The index of 11 in array is: "+l.findTarget(arr, n, 11));
        // Q6
        System.out.println("GCD(15,25) = "+l.GCD(15, 25));
        System.out.println("GCD(45,10) = "+l.GCD(45, 10));
        // Q7
        System.out.println("Power(3, 5) = "+l.power(3, 5));
        // Q8
        System.out.println("Factoria(15) = "+l.fact(15));
        // Q9
        System.out.println("Fibonacci(9) = "+l.fib(9));
        System.out.println("Fibonacci(11) = "+l.fib(11));
        // Q10
        System.out.println("the sum of the first 6 reciprocals = "+l.addReciprocals(6));
        // Q11 - Q12
        Lab3 bt = new Lab3();
        bt.root = new Node(3);
        bt.root.left = new Node(4);
        bt.root.right = new Node(5);
        bt.root.left.left = new Node(6);
        bt.root.left.right = new Node(7);
        System.out.println("The height of binary tree: "+ bt.height(bt.root));
        System.out.println("The size of binary tree: "+ bt.size(bt.root));
        
    }
    
}
