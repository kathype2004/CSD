/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q1;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Stack stack = new Stack();
        stack.push(5);
        stack.push(10);
        stack.push(15);
        stack.traverse();
        System.out.println("Top element: " + stack.top());
        System.out.println("Popped element: " + stack.pop());
        stack.traverse();
        stack.convertToBinary(13);
    }
}
   
