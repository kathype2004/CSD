/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

import java.util.EmptyStackException;

/**
 *
 * @author My Compter
 */
public class CharStack {
    private CharNode top;

    private class CharNode {
        char data;
        CharNode next;

        CharNode(char data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void clear() {
        top = null;
    }

    public void push(char x) {
        CharNode newNode = new CharNode(x);
        newNode.next = top;
        top = newNode;
    }

    public char pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        char data = top.data;
        top = top.next;
        return data;
    }

    public char top() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return top.data;
    }

    public void traverse() {
        CharNode current = top;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
