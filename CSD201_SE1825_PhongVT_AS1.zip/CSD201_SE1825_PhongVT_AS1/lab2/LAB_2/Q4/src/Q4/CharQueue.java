/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

import java.util.NoSuchElementException;

/**
 *
 * @author My Compter
 */
public class CharQueue {
    private CharNode front;
    private CharNode rear;

    private class CharNode {
        char data;
        CharNode next;

        CharNode(char data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void clear() {
        front = null;
        rear = null;
    }

    public void enqueue(char x) {
        CharNode newNode = new CharNode(x);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public char dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        char data = front.data;
        if (front == rear) {
            front = null;
            rear = null;
        } else {
            front = front.next;
        }
        return data;
    }

    public char first() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return front.data;
    }

    public void traverse() {
        CharNode current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
