/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
           // Test CharStack
        CharStack charStack = new CharStack();
        charStack.push('a');
        charStack.push('b');
        charStack.push('c');
        charStack.traverse();
        System.out.println("Top element: " + charStack.top());
        System.out.println("Popped element: " + charStack.pop());
        charStack.traverse();

        // Test CharQueue
        CharQueue charQueue = new CharQueue();
        charQueue.enqueue('X');
        charQueue.enqueue('Y');
        charQueue.enqueue('Z');
        charQueue.traverse();
        System.out.println("First element: " + charQueue.first());
        System.out.println("Dequeued element: " + charQueue.dequeue());
        charQueue.traverse();
    }
    
}
