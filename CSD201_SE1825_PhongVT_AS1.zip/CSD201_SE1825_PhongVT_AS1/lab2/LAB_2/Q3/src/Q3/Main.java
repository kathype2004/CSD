/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q3;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                // Test StringStack
        StringStack stringStack = new StringStack();
        stringStack.push("Hello");
        stringStack.push("World");
        stringStack.push("Stack");
        stringStack.traverse();
        System.out.println("Top element: " + stringStack.top());
        System.out.println("Popped element: " + stringStack.pop());
        stringStack.traverse();

        // Test StringQueue
        StringQueue stringQueue = new StringQueue();
        stringQueue.enqueue("This");
        stringQueue.enqueue("is");
        stringQueue.enqueue("a");
        stringQueue.enqueue("Queue");
        stringQueue.traverse();
        System.out.println("First element: " + stringQueue.first());
        System.out.println("Dequeued element: " + stringQueue.dequeue());
        stringQueue.traverse();
    }
    
}
