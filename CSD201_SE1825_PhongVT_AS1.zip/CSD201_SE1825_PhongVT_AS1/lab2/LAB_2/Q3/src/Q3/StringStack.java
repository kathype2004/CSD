/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q3;

import java.util.EmptyStackException;

/**
 *
 * @author My Compter
 */
public class StringStack {
     private StringNode top;

    private class StringNode {
        String data;
        StringNode next;

        StringNode(String data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void clear() {
        top = null;
    }

    public void push(String x) {
        StringNode newNode = new StringNode(x);
        newNode.next = top;
        top = newNode;
    }

    public String pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        String data = top.data;
        top = top.next;
        return data;
    }

    public String top() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return top.data;
    }

    public void traverse() {
        StringNode current = top;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
