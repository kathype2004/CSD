/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q3;

import java.util.NoSuchElementException;

/**
 *
 * @author My Compter
 */
public class StringQueue {
    private StringNode front;
    private StringNode rear;

    private class StringNode {
        String data;
        StringNode next;

        StringNode(String data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void clear() {
        front = null;
        rear = null;
    }

    public void enqueue(String x) {
        StringNode newNode = new StringNode(x);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public String dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        String data = front.data;
        if (front == rear) {
            front = null;
            rear = null;
        } else {
            front = front.next;
        }
        return data;
    }

    public String first() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return front.data;
    }

    public void traverse() {
        StringNode current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
