/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q2;

import java.util.NoSuchElementException;

/**
 *
 * @author My Compter
 */
public class Queue {
    private Node front;
    private Node rear;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void clear() {
        front = null;
        rear = null;
    }

    public void enqueue(int x) {
        Node newNode = new Node(x);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        int data = front.data;
        if (front == rear) {
            front = null;
            rear = null;
        } else {
            front = front.next;
        }
        return data;
    }

    public int first() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return front.data;
    }

    public void traverse() {
        Node current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void convertRealToBinary(double number) {
        clear();
        int precision = 32; // Assuming 32-bit precision
        while (number > 0 && precision > 0) {
            number = number * 2;
            if (number >= 1) {
                enqueue(1);
                number = number - 1;
            } else {
                enqueue(0);
            }
            precision--;
        }
        System.out.print("Binary representation: ");
        traverse();
    }
}
