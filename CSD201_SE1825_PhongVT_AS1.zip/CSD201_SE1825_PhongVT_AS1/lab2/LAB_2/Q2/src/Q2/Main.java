/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q2;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Queue queue = new Queue();
        queue.enqueue(5);
        queue.enqueue(10);
        queue.enqueue(15);
        queue.traverse();
        System.out.println("First element: " + queue.first());
        System.out.println("Dequeued element: " + queue.dequeue());
        queue.traverse();
        queue.convertRealToBinary(0.625);
    }
}
   
