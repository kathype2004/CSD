/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q5;

import java.util.EmptyStackException;

/**
 *
 * @author My Compter
 */
public class ObjectStack {
    private ObjectNode top;

    private class ObjectNode {
        Object data;
        ObjectNode next;

        ObjectNode(Object data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void clear() {
        top = null;
    }

    public void push(Object x) {
        ObjectNode newNode = new ObjectNode(x);
        newNode.next = top;
        top = newNode;
    }

    public Object pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        Object data = top.data;
        top = top.next;
        return data;
    }

    public Object top() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return top.data;
    }

    public void traverse() {
        ObjectNode current = top;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
