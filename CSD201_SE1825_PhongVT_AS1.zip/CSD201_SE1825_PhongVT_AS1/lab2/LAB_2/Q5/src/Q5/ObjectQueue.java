/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q5;

import java.util.NoSuchElementException;

/**
 *
 * @author My Compter
 */
public class ObjectQueue {
    private ObjectNode front;
    private ObjectNode rear;

    private class ObjectNode {
        Object data;
        ObjectNode next;

        ObjectNode(Object data) {
            this.data = data;
        }
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void clear() {
        front = null;
        rear = null;
    }

    public void enqueue(Object x) {
        ObjectNode newNode = new ObjectNode(x);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public Object dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        Object data = front.data;
        if (front == rear) {
            front = null;
            rear = null;
        } else {
            front = front.next;
        }
        return data;
    }

    public Object first() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        return front.data;
    }

    public void traverse() {
        ObjectNode current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
