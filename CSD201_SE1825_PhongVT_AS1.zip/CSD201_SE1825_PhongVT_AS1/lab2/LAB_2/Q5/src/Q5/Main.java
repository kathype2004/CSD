/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q5;

/**
 *
 * @author My Compter
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Test ObjectStack
        ObjectStack computerStack = new ObjectStack();
        computerStack.push("Macbook");
        computerStack.push("Surface Pro");
        computerStack.push("ThinkPad");
        computerStack.traverse();
        System.out.println("Top element: " + computerStack.top());
        System.out.println("Popped element: " + computerStack.pop());
        computerStack.traverse();

        // Test ObjectQueue
        ObjectQueue computerQueue = new ObjectQueue();
        computerQueue.enqueue("Dell XPS");
        computerQueue.enqueue("HP Spectre");
        computerQueue.enqueue("Lenovo Yoga");
        computerQueue.traverse();
        System.out.println("First element: " + computerQueue.first());
        System.out.println("Dequeued element: " + computerQueue.dequeue());
        computerQueue.traverse();
    }
}
