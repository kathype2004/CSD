
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
class Node_String{
    String info;
    Node_String left, right;
    Node_String(){}
    Node_String(String s){
        this.info = s;
        left = right = null;
    }
}
class QueueString {
    LinkedList a;
    public QueueString() {
        a = new LinkedList();
    }
    boolean isEmpty() {
        return a.isEmpty();
    }
    void enqueue(Object o) {
        a.add(o);
    }
    Object dequeue() {
        return a.removeFirst();
    }
    void clear() {
        a.clear();
    }
    
}
public class Question2 {
    Node_String root = new Node_String();
    public Question2(){
        root = null;
    }
    // function 1: check empty
    boolean isEmpty() {
        return (root == null);
    }
    // function 2: clear
    void clear(MyQueue q) {
        q.clear();
    }
    // function 3: search
        // recursion
    Node_String search(Node_String root, String s){
        if(root == null)    return null;
         if(root.info.compareTo(s)==1){
            return search(root.left, s);
        }else if(root.info.compareTo(s)==-1){
            return search(root.right, s);
        }
        // if root.info == x
        return root;
    }
    // function 4: insert
        // non recursion
    void insert(String s) {
        Node_String p = new Node_String(s);
        if (isEmpty()) {
            root = p;
            return;
        }
        Node_String f = null;
        Node_String q = root;
        while (q != null) {
            if (q.info.equalsIgnoreCase(s)) {
                System.out.println("This value is exist in tree.");break;
            }
            // identify the position for node inserted
            f = q;
            if (q.info.compareTo(s)>0) {
                q = q.left;
            } else if(q.info.compareTo(s)<0) {
                q = q.right;
            }
        }
        if (f.info.compareTo(s)>0) {
            f.left = p;
        } else {
            f.right = p;
        }
    }
    void visit(Node_String p) {
        System.out.print(p.info + " ");
    }
    // function 5: use dequeue to print the breath array
    void breadth() {
//        Node_String p = root;
        if (isEmpty()) {
            System.out.println("This tree is empty.");
        }
        MyQueue queue = new MyQueue();
        queue.enqueue(root);
        Node_String q;
        while(!queue.isEmpty()){
            q = (Node_String)queue.dequeue();
            if(q.left!=null) queue.enqueue(q.left);
            if(q.right!=null) queue.enqueue(q.right);
            visit(q);  
        }
        System.out.println("");
    }
    // function 6
    void preorder(Node_String p) {
        if (p == null) {
            return;
        }
        visit(p);
        preorder(p.left);
        preorder(p.right);
    }
    // function 7
    void inorder(Node_String root) {
        if (root == null) {
            return;
        }
        inorder(root.left);
        visit(root);
        inorder(root.right);
    }

    // function 8
    void postorder(Node_String p) {
        if (p == null) {
            return;
        }
        postorder(p.left);
        postorder(p.right);
        visit(p);
    }
    // function 9
    static int totalNode(Node_String root) {
        if (root == null) {
            return 0;
        }
        int l = totalNode(root.left);
        int r = totalNode(root.right);
        return l + r + 1;
    }

    int count() {
        return totalNode(root);
    }
    // function 10: 
    Node_String deleteNode(Node_String root, String key) {
        if (root == null) {
            return root;
        }
        if (root.info.compareTo(key)>0) {
            root.left = deleteNode(root.left, key);
            return root;
        } else if (root.info.compareTo(key)<0) {
            root.right = deleteNode(root.right, key);
            return root;
        }
        if (root.left == null) {
            Node_String temp = root.right;
            return temp;
        } else if (root.right == null) {
            Node_String temp = root.left;
            return temp;
        } else {
            Node_String succParent = root;
            Node_String succ = root.right;
            while (succ.left != null) {
                succParent = succ;
                succ = succ.left;
            }
            if (succParent != root) {
                succParent.left = succ.right;
            } else {
                succParent.right = succ.right;
            }
            root.info = succ.info;
            return root;
        }
    }
    void dele(String s) {
        root = deleteNode(root, s);
    }
    int findHeight(Node_String root){
        if(root == null) return 0;
        return 1+ Math.max(findHeight(root.left), findHeight(root.right));
    }
    // function 17
    boolean ALV(Node_String root){
        if(Math.abs(findHeight(root.left)-findHeight(root.right))>1){
            return false;
        }
        return true;
    }
    public static void main(String[] args){   
        Question2 bst = new Question2();
        String[] car = {"BMW","Merc","HuynDai","Volvo","Kia","Lamboghini", "Ferrari","Porche"};
        for (String string : car) {
            bst.insert(string);
        }
        System.out.println("- value of root node: "+bst.root.info);
        System.out.print("- The breadth of tree: ");bst.breadth();
        System.out.println("- The size of tree: "+ bst.count());
        System.out.print("- Delete \"HuynDai\" in binary tree: ");bst.dele("HuynDai"); bst.breadth();
        System.out.println("- Height of tree: "+bst.findHeight(bst.root));
        System.out.println("- This tree is ALV: " + bst.ALV(bst.root));
    }
}
