
import java.util.LinkedList;

// use dequeue to print the order of binary tree
class Node_Int {
    int info;
    Node_Int left;
    Node_Int right;
    public Node_Int(){}
    public Node_Int(int x) {
        this.info = x;
        left = right = null;
    }
}
class MyQueue {
    LinkedList a;
    public MyQueue() {
        a = new LinkedList();
    }
    boolean isEmpty() {
        return a.isEmpty();
    }
    void enqueue(Object o) {
        a.add(o);
    }
    Object dequeue() {
        return a.removeFirst();
    }
    void clear() {
        a.clear();
    }
    
}

public class Question1 {
    Node_Int root = new Node_Int();
    public Question1() {
        root = null;
    }
    // function 1: check empty
    boolean isEmpty() {
        return (root == null);
    }
    // function 2: clear
    void clear(MyQueue q) {
        q.clear();
    }
    // function 3: search
        // recursion
    Node_Int search(Node_Int root, int x){
        if(root == null)    return null;
         if(root.info>x){
            return search(root.left, x);
        }else if(root.info < x){
            return search(root.right, x);
        }
        // if root.info == x
        return root;
    }
        // non-recursion
//    Node searchN(Node root, int x){
//        if(root == null) return null; // null
//        if(root.info == x) return root; // == root
//        Node f = null, p = root; // f: asign variabe, p: asign root
//        while(p!=null){
//            if(root.info>x) p = p.left;
//            else if (root.info<x) p = p.right;
//            f = p;
//        }
//        if(f.info == x) return f;
//        return null;
//    }
    
    // function 4: insert
        // non recursion
    void insert(int x) {
        Node_Int p = new Node_Int(x);
        if (isEmpty()) {
            root = p;
            return;
        }
        Node_Int f = null;
        Node_Int q = root;
        while (q != null) {
            if (q.info == x) {
                System.out.println("This value is exist in tree.");return;
            }
            // identify the position for node inserted
            f = q;
            if (q.info > x) {
                q = q.left;
            } else if(q.info<x) {
                q = q.right;
            }
        }
        if (f.info > x) {
            f.left = p;
        } else {
            f.right = p;
        }
    }
        // recursion
//    Node insert(int x){
//        Node p = new Node(x);
//        if(root == null){
//            return root = p;
//        }else if(root.info == x){
//            return null;
//        }else {
//            if(root.info>x){
//                return root.left = insert(root.left, x);
//            }else if(root.info<x){
//                return root.right = insert(root.right, x);
//            }
//        }
//        return root;
//    }
    // function 5: use dequeue to print the breath array
    void breadth() {
        Node_Int p = root;
        if (isEmpty()) {
            System.out.println("This tree is empty.");
        }
        MyQueue queue = new MyQueue();
        queue.enqueue(p);
        Node_Int q;
        while(!queue.isEmpty()){
            q = (Node_Int)queue.dequeue();
            if(q.left!=null) queue.enqueue(q.left);
            if(q.right!=null) queue.enqueue(q.right);
            visit(q);  
        }
    }
    // function 6
    void visit(Node_Int p) {
        System.out.print(p.info + " ");
    }
    void preorder(Node_Int p) {
        if (p == null) {
            return;
        }
        visit(p);
        preorder(p.left);
        preorder(p.right);
    }

    // function 7
    void inorder(Node_Int root) {
        if (root == null) {
            return;
        }
        inorder(root.left);
        visit(root);
        inorder(root.right);
    }

    // function 8
    void postorder(Node_Int p) {
        if (p == null) {
            return;
        }
        postorder(p.left);
        postorder(p.right);
        visit(p);
    }

    // function 9
    static int totalNode(Node_Int root) {
        if (root == null) {
            return 0;
        }
        int l = totalNode(root.left);
        int r = totalNode(root.right);
        return l + r + 1;
    }

    int count() {
        return totalNode(root);
    }

    // function 10: 
    Node_Int deleteNode(Node_Int root, int key) {
        if (root == null) {
            return root;
        }
        // Recursive calls for ancestors of node to be deleted
        if (root.info > key) {
            root.left = deleteNode(root.left, key);
            return root;
        } else if (root.info < key) {
            root.right = deleteNode(root.right, key);
            return root;
        }

        // We reach here when root is the node to be deleted.
        // If one of the children is empty
        if (root.left == null) {
            Node_Int temp = root.right;
            return temp;
        } else if (root.right == null) {
            Node_Int temp = root.left;
            return temp;
        } // If both children exist
        else {
            Node_Int succParent = root;
            // Find successor
            Node_Int succ = root.right;
            while (succ.left != null) {
                succParent = succ;
                succ = succ.left;
            }
            // Delete successor. Since successor
            // is always left child of its parent
            // we can safely make successor's right
            // right child as left of its parent.
            // If there is no succ, then assign
            // succ.right to succParent.right
            if (succParent != root) {
                succParent.left = succ.right;
            } else {
                succParent.right = succ.right;
            }
            // Copy Successor Data to root
            root.info = succ.info;

            // Delete Successor and return root
            return root;
        }
    }
    void dele(int x) {
        root = deleteNode(root, x);
    }
    // function 11: max value in tree
    Node_Int max(){
        Node_Int p = root;
        while(p!=null){
            p = p.right;
        }
        return p;
    }
    // function 12: 
    Node_Int min(){
        Node_Int p = root;
        while(p!=null){
            p = p.left;
        }
        return p;
    }
    //function 13
    int sum(Node_Int root){
        if(root==null) return 0;
        return root.info+sum(root.left)+sum(root.right);
    }
    // function 14
    int avg(){
        return sum(root)/totalNode(root);
    }
    // function 15
    int findHeight(Node_Int root){
        if(root == null) return 0;
        return 1+ Math.max(findHeight(root.left), findHeight(root.right));
//        int right = 0, left = 0;
//        if(root.right !=null){
//            right = this.findHeight(root.right);
//        }
//        if(root.left != null){
//            left = this.findHeight(root.left);
//        }
//        return 1+ Math.max(right, left);
    }
//     int findHeight(Node temp){  
//        //Check whether tree is empty  
//        if(root == null) {  
//             System.out.println("Tree is empty");  
//            return 0;  
//        }  
//        else {  
//            int leftHeight = 0, rightHeight = 0;  
//  
//            //Calculate the height of left subtree  
//            if(temp.left != null)  
//                leftHeight = findHeight(temp.left);  
//  
//            //Calculate the height of right subtree  
//            if(temp.right != null)  
//                rightHeight = findHeight(temp.right);  
//  
//            //Compare height of left subtree and right subtree  
//            //and store maximum of two in variable max  
//            int max = (leftHeight > rightHeight) ? leftHeight : rightHeight;  
//  
//            //Calculate the total height of tree by adding height of root  
//            return (max + 1);  
//        }  
//     }  
    // funciton 16
    int maxValuePath(Node_Int root){
        if(root == null) return 0;
        int valueLeft = root.info+ maxValuePath(root.left);
        int valueRight = root.info+ maxValuePath(root.right);
        return ((valueLeft-valueRight)>0)? valueLeft:valueRight;
    }
    // function 17
    boolean ALV(Node_Int root){
        if(Math.abs(findHeight(root.left)-findHeight(root.right))>1){
            return false;
        }
        return true;
    }
    // Q19
    boolean isCompleteUtil(Node_Int root, int index,
                        int number_nodes)
    {
        if (root == null)
            return true;
        if (index >= number_nodes)
            return false;
        return isCompleteUtil(root.left,2 * index + 1,number_nodes)
            && isCompleteUtil(root.right,2 * index + 2,number_nodes);
    }
    boolean isHeapUtil(Node_Int root)
    {
        if (root.left == null && root.right == null)
            return true;
        if (root.right == null) {
            return root.info >= root.left.info;
        }
        else {
            if (root.info >= root.left.info&& root.info >= root.right.info)
                return isHeapUtil(root.left)&& isHeapUtil(root.right);
            else
                return false;
        }
    }
    public boolean isHeap(Node_Int root)
    {
        if (root == null)
            return true;
        int node_count = totalNode(root);
        if (isCompleteUtil(root, 0, node_count) == true
            && isHeapUtil(root) == true)
            return true;
        return false;
    }
    // main
    public static void main(String[] args){
        Question1 bst = new Question1();
        // insert value of array a
        int [] a = {11,5,9,7,13};
        for(int i=0;i<a.length;i++){
            bst.insert(a[i]);
        }
        System.out.println("Root of the tree: " + bst.root.info);
        System.out.print("BST after insertion (11 5 9 7 13):");
        System.out.print("\n - Pre-order traverse       "); bst.preorder(bst.root);  
        System.out.print("\n - In-order traverse        "); bst.inorder(bst.root);  
        System.out.print("\n - Post-order traverse      "); bst.postorder(bst.root);  
        System.out.print("\n - Breadth-first traverse   "); bst.breadth();
        System.out.print("\n - Delete value 5 in tree: ");bst.dele(5); bst.breadth();
        System.out.print("\n - Height of root of tree: "+ bst.findHeight(bst.root));
        System.out.print("\n - Maximum sum of tree: "+ bst.maxValuePath(bst.root)); 
        System.out.print("\n - This tree is ALV: "+ bst.ALV(bst.root)); 
        if (bst.isHeap(bst.root) == true)
            System.out.print("\n - Given Binary Tree is a Max-Heap");
        else
            System.out.print("\n - Given Binary Tree is not a Max-Heap");
    }
        /*       11        - Pre-order traverse     11 5 9  7  13         
                /  \       - In-order traverse      5  7 9  11 13         
               5   13      - Post-order traverse    7  9 5  13 11    
                \          - Level-order traverse   11 5 13 9  7          
                 9           (Breadth-first)        
                /
               7               
        */

}
